﻿namespace XLua
{
    public interface RawObject
    {
        object Target { get; }
    }
}
