﻿using UnityEngine;
using System.Collections;
using System;

namespace MFramework.UI.Layout
{

    public class BaseLayoutButton : MonoBehaviour, ILayerItem
    {
        //    [HideInInspector]
        public int m_ItemIndex = 0;
        protected Vector3 intialWorldPosition;
        [SerializeField]
        private int _dataIndex;
        public int m_DataIndex
        {
            get { return _dataIndex; }
            protected set { _dataIndex = value; }
        }

        public LayoutScrollView LayoutScrollViewScript { get; protected set; }

        private Vector3 IntialLocal;
        public Vector3 m_IntialLocal
        {
            get { return IntialLocal; }
            protected set { IntialLocal = value; }
        }
        [SerializeField]
        private SerelizeVector2_Int _viewRelativeIndex = new SerelizeVector2_Int(-1, -1);
        public SerelizeVector2_Int ViewRelativeIndex
        {
            get { return _viewRelativeIndex; }
            set { _viewRelativeIndex = value; }
        }

        /// <summary>
        /// 使用默认的视图
        /// </summary>
        protected virtual void OnDisable()
        {

        } 

        /// <summary>
        /// 按钮项初始化
        /// </summary>
        /// <param name="_sender">穿件的View</param>
        /// <param name="_data"></param>
        public virtual void InitialButtonItem(object _sender, int _dataIndex, int _relativeIndexList = -1, int _relativeIndexItem = -1)
        {
            m_DataIndex = _dataIndex;
            ViewRelativeIndex = new SerelizeVector2_Int(_relativeIndexList, _relativeIndexItem);
            LayoutScrollViewScript = _sender as LayoutScrollView;
        }
        public void StorePosition(Vector3 _position, Vector3 _worldPosition, int _itemIndex, int _dataIndex)
        {
            m_IntialLocal = _position;
            intialWorldPosition = _worldPosition;
            m_ItemIndex = _itemIndex;
            m_DataIndex = _dataIndex;
            //  Debug.Log(gameObject.name+"  "+ _position +"    "+ _worldPosition);
        }
        /// <summary>
        /// 列表项特效
        /// </summary>
        /// <param name="_isOpen"></param>
        /// <param name="delayTime">延迟打开时间</param>
        public virtual void PlayEffect(bool _isOpen, float delayTime = 0f) { }

        public virtual void UpdateData(CollectionEvent itemEvent, object data)
        {
            switch (itemEvent)
            {
                case CollectionEvent.Update:
                    #region Update
                    FlushView();
                    #endregion
                    break;
                default:
                    Debug.LogError("UpdateData Fail.....Not Define " + itemEvent);
                    break;
            }
        }


        public virtual void FlushView()
        {

        }


    }
}
